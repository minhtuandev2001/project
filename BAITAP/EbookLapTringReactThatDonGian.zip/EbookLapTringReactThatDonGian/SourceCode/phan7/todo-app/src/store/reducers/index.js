import { combineReducers } from 'redux';
import color from './themeReducer';

export default combineReducers({
    color
});
