import React from "react";
import ReactDOM from "react-dom";
import "./App.css";
import TodoApp from "./components/TodoApp";

ReactDOM.render(<TodoApp />, document.getElementById("root"));
