import React from "react";
import ReactDOM from "react-dom";
import MemeApp from "./components/MemeApp";
import "./App.css";

ReactDOM.render(<MemeApp />, document.getElementById("root"));
